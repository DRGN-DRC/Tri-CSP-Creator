#!/usr/bin/env python

# Created by DRGN of Smashboards (Daniel R. Cappel)
# Version 2.1.1

# For console interaction:
# image = gimp.image_list()[0]

from gimpfu import *

def saveToFile(image, layer, outputFolder, filename):
    # Indicate that the process has started.
    gimp.progress_init("Saving to '" + outputFolder + "'...")
    
    try:
        # Save as PNG
        gimp.pdb.file_png_save2(image, layer, outputFolder + "\\" + filename + ".png", "raw_filename", 0, 9, 0, 0, 0, 0, TRUE, 0, 0)
                        # (image, drawable, filename, raw_filename, interlace, compression, bkgd, gama, offs, phys, time, comment, svtrans)
    except Exception as err:
        gimp.message("Unexpected error: " + str(err))
    
def finish_csp(timg, tdrawable, outputFolder, filename, saveRef, saveWithPalette):
    image = timg
    width = image.width
    height = image.height

    # Check for a selection area to use for cropping.
    selectionExists, x1, y1, x2, y2 = pdb.gimp_selection_bounds(image)

    if not selectionExists:
        pdb.gimp_message('Operation aborted. To begin, you must first select a region to crop to, or select the whole image (Ctrl-A).')
    else:
        # Disable history recording, so the plug-in's actions can be undone in one step.
        pdb.gimp_image_undo_group_start(image)

        # Crop the image based on the current selection (emulates the 'Fit Canvas to Selection' function).
        # (This method must be used because GIMP's standard crop feature will delete layer portions 
        # that are outside of the canvas area, which are needed during later layer moves.)
        new_width = x2 - x1
        new_height = y2 - y1
        pdb.gimp_image_resize(image, new_width, new_height, 0, 0)
        pdb.gimp_selection_none(image)

        # If more than one layer is present, merge what is visible into one layer, and delete the rest.
        # (This is necessary because if other layers are present, even if not visible, GIMP will take
        # their colors into account when generating a palette for the image.)
        numOfLayers = len(image.layers)
        if numOfLayers > 1:
            initialComposite = pdb.gimp_image_merge_visible_layers(image, 0)
            for layer in image.layers:
                if not layer.name == initialComposite.name:
                    pdb.gimp_image_remove_layer(image, layer)
        else:
            initialComposite = image.active_layer

        # The '_image_resize' method done earlier doesn't seem to handle the last two parameters correctly
        # (which is why they're set at 0), so this step below compensates for it by moving the layer.
        initialComposite.translate(-x1, -y1)

        highResMultiplier = int( round( new_width / 136.0 ) ) # Multiplier to keep the shadow relative offset proportional to the CSP size

        if not pdb.gimp_drawable_is_indexed(initialComposite):

            def addBackground( layerType, shadowOpacity, highResMultiplier ):
                # Duplicate the original layer and move it to the shadow position.
                compositeCopy = initialComposite.copy()
                pdb.gimp_image_insert_layer(image, compositeCopy, None, 1)
                compositeCopy.translate( (-10 * highResMultiplier), (10 * highResMultiplier) )

                # Select the alpha channel of the duplicated layer, and create a new layer for the shadow.
                pdb.gimp_image_select_item(image, 0, compositeCopy) # Alpha to Selection
                shadowLayer = gimp.Layer(image, "The shadow", width, height, layerType, 100, 0) # Image type 1 = RGBA
                pdb.gimp_image_insert_layer(image, shadowLayer, None, 2)

                # Fill the selection to the new layer. This method prevents any colors from the duplicated layer from persisting.
                pdb.gimp_edit_fill(shadowLayer, 0) # Fill with foreground (set before calling this function)
                pdb.gimp_selection_none(image)
                pdb.gimp_layer_set_opacity(shadowLayer, shadowOpacity)

                # Remove the no-longer-needed duplicated layer.
                pdb.gimp_image_remove_layer(image, compositeCopy)

                return shadowLayer


            # Create a _6 type image (a PNG with regular transparency and shadow) alongside the paletted _9 image.
            if saveRef == True:
                gimp.set_foreground(0, 0, 0) # Will be the shadow color.
                shadowLayer = addBackground( RGBA_IMAGE, 50, highResMultiplier )

                # Save the finished layer to a PNG file. 
                if not outputFolder == '' and not filename == '':
                    finalCopy = initialComposite.copy()
                    pdb.gimp_image_insert_layer(image, finalCopy, None, 1)
                    finalComposite = pdb.gimp_image_merge_down(image, finalCopy, 1)
                    saveToFile(image, finalComposite, outputFolder, filename) # (Ignores initialComposite)
                    if saveWithPalette:
                        pdb.gimp_image_remove_layer(image, finalComposite)

            if saveWithPalette:
                # Create the palette for the image and add in the replacement colors (lime green and magenta).
                pdb.gimp_image_convert_indexed(image, 0, 0, 254, FALSE, FALSE, 'New_Palette')
                                            # (image, dither_type, palette_type, num_cols, alpha_dither, remove_unused, palette)
                                                        # Dither types:
                                                                # 0 = None
                                                                # 1 = Floyd-Steinberg error diffusion
                                                                # 2 = Floyd-Steinberg error diffusion with reduced bleeding
                                                                # 3 = dithering based on pixel location ('Fixed' dithering)
                colormap = pdb.gimp_image_get_colormap(image)[1]
                colormap = colormap + (0, 255, 0, 255, 0, 255) # Add lime green and magenta, respectively.
                pdb.gimp_image_set_colormap(image, len(colormap), colormap)

                # Create the character's shadow.
                gimp.set_foreground(0, 255, 0) # For a lime green shadow.
                shadowLayer = addBackground( 5, 100, highResMultiplier ) # Image type 5 = INDEXEDA (GIMP doesn't actually recognize the latter form)

                # Add a magenta background.
                bgLayer = gimp.Layer(image, 'Background', width, height, 5, 100, 0)
                pdb.gimp_image_insert_layer(image, bgLayer, None, 2)
                gimp.set_background(255, 0, 255)
                pdb.gimp_edit_fill(bgLayer, BACKGROUND_FILL) # Fill with background (magenta)

                # Merge the layers and save the image to a PNG file.
                if not outputFolder == '' and not filename == '':
                    finalComposite = pdb.gimp_image_merge_visible_layers(image, 1)
                    saveToFile(image, finalComposite, outputFolder, filename + ' _9')
        else: # The initial image already had a palette. Abort the script.
            pdb.gimp_message('The image already has a palette. Operation aborted.')

        # Reactivate history recording.
        pdb.gimp_image_undo_group_end(image)


register(
        "finish_csp",
        "Create a finished, paletted CSP from a RGBA image.",
        ("Creates a finished, paletted CSP from a RGBA image. \n\n"
            "To use this, first create a selection for the area "
            "you would like to crop to. For CSPs, the size needs to be 136x188.\n\n"
            "(Leave either field below blank if you don't want to save "
            "a PNG file of the finished image(s).)"),
        "DRGN (Daniel R. Cappel)",
        "DRGN (Daniel R. Cappel)",
        "Dec. 2014",
        "<Image>/CS_Ps/_Add Shadow and Save",
        "*",
        [
                (PF_STRING, "outputFolder", "Output directory", ""),
                (PF_STRING, "filename", "File name", "(File extension not required.)"),
                (PF_BOOL, "saveRef", "Save __6 Version", TRUE),
                (PF_BOOL, "saveWithPalette", "Create __9 Version", TRUE)
        ],
        [],
        finish_csp)

main()